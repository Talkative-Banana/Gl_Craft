## Bedrock Add-On Sample Files

The following sample files provide the latest resource and behavior examples for creating Add-Ons for Minecraft: Bedrock Edition. The source of these files is available at https://github.com/mojang/bedrock-samples. For more information on how to create Add-Ons for Minecraft, please visit https://minecraft.net/creator and https://learn.microsoft.com/minecraft/creator.

You can see versions of this documentation corresponding to the latest previews in the [preview branch](https://github.com/Mojang/bedrock-samples/tree/preview).

A version of the main documentation can also be found at [https://mojang.github.io/bedrock-samples/](https://mojang.github.io/bedrock-samples/).